document.getElementById("getBatteryStatus").addEventListener("click", onBatteryStatus);

window.addEventListener("batterystatus", onBatteryStatus, false);

function onBatteryStatus(info) {
    if(info.level!=undefined){
        alert("BATTERY STATUS:  Level: " + info.level + " isPlugged: " + info.isPlugged);
    }
}
